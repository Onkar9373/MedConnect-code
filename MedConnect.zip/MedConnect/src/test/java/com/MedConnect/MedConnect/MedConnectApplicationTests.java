package com.MedConnect.MedConnect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedConnectApplicationTests {

	@Test
	void contextLoads() {
	}

}
