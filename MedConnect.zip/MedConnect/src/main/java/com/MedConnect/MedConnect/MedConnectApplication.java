package com.MedConnect.MedConnect;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedConnectApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedConnectApplication.class, args);
	}

}
